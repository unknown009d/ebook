# PDF Viewer

> Custom PDF viewer with pagination built with pdf.js
